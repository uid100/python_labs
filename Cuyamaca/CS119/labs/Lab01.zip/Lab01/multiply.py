#!/usr/bin/env python3

# Dan Sullivan
# Cuyamaca College CS-119
# Lab 1, exercise 1

# multiply 2 numbers and display the product

# declare variables
number1 = 0
number2 = 0
product = 0

# input
number1 = int(input("Enter the first number to use: "))
number2 = int(input("Enter the second number: "))

# process
product = number1 * number2

# output
print("The product is " + str(product))
